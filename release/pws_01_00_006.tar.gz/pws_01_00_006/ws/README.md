Demo List:

01 : The Simplest Web Service

02 : Framework Callbacks

03 : Managing Credentials

04 : Using DetailLevel 

05 : DetailLevel for arrays

06 : subObject DetailLevel

07 : Array DetailLevel






